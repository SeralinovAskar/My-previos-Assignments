public class Task1 {
}
//DFS Trace from Node A:

//Start at A
//Visit C (first unvisited neighbor of A)
//Visit B (first unvisited neighbor of C)
//Visit E (first unvisited neighbor of B)
//Visit G (first unvisited neighbor of E)
//Visit F (first unvisited neighbor of G)
//Visit D (remaining unvisited neighbor of A)

//Order of Visits: (A, C, B, E, G, F, D)